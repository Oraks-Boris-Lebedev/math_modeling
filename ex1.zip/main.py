import my_module
print(my_module.a)
b=my_module.a**2
print(b)