from my_module import *
print(a*b-c)