def mult_func(a):
  x=a*3
  return x
tmp=mult_func(4)
print(tmp)
print(mult_func(10))
print(mult_func('Goog '))
def print_func(a):
  print(f'Я печатаю:{a}')
print_func('Hello')
  