x0=10           #глоб. обл.
def move(t):
  x=x0*t        #лок. обл.
  return x
print (move(3))
#print (x)      #ОШИБКА!!!
