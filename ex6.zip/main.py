from my_module1 import a
from my_module2 import a
print(a)
import my_module1
import my_module2
print(my_module1.a * my_module2.a)