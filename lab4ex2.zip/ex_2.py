def mult_func(a):
  a0=1
  for i in a:
    a0=a0*i
  print (a0)
mult_func([8, 9, 14])