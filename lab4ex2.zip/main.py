import numpy
import ex_2