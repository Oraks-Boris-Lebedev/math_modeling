import my_module as mm
print(mm.a)
print(mm.a/(1-mm.a**3))